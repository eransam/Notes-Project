// הכנסת פתק חדש לסטורג'
function addNoteToStorage() {
  event.preventDefault();
  const mainInput = document.getElementById("mainInput");
  const dateInput = document.getElementById("dateInput");
  const timeInput = document.getElementById("timeInput");

  //ולידציה - מילוי משימה ותאריך
  if (mainInput.value.length === 0 && dateInput.value.length === 0) {
    alert("Plese determain your task and dead-line");
    return;
  }
  if (mainInput.value.length === 0) {
    alert("Plese determain your task");
    return;
  }
  if (dateInput.value.length === 0) {
    alert("Plese determain your dead-line");
    return;
  }

  // יצירת אובייקט
  let newNote = {
    text: mainInput.value,
    date: dateInput.value,
    time: timeInput.value,
  };

  // הכנסה לזיכרון
  const savedNotesArrayJson = localStorage.getItem("stored-notes");
  let notesArray =
    savedNotesArrayJson === null ? [] : JSON.parse(savedNotesArrayJson);
  notesArray.push(newNote);

  const notesArrayJson = JSON.stringify(notesArray);
  localStorage.setItem("stored-notes", notesArrayJson);

  // הדפסה
  const timeOfNote = "first";
  printNote(
    mainInput.value,
    dateInput.value,
    timeInput.value,
    notesArray.length,
    timeOfNote
  );
  reloadTimer();
}

// יצירת פתק
function printNote(mainInput, dateInput, timeInput, placeInArry, timeOfNote) {
  const allnotesDiv = document.getElementById("allnotesDiv");

  // יצירת אלמנטים בפתק
  let restNoteDiv = document.createElement("DIV");
  allnotesDiv.appendChild(restNoteDiv);
  if (timeOfNote === "first") {
    restNoteDiv.classList = "restNoteDiv col-6 col-md-3 col-lg-2 fade-in";
  } else {
    restNoteDiv.classList = "restNoteDiv col-6 col-md-3 col-lg-2";
  }
  let noteDiv = document.createElement("DIV");
  restNoteDiv.appendChild(noteDiv);
  noteDiv.classList = "noteDiv";

  let textDiv = document.createElement("DIV");
  textDiv.classList = "textDiv";
  noteDiv.appendChild(textDiv);

  let TextArea = document.createElement("TEXTAREA");
  TextArea.classList = "TextArea bg-transparent border-0";
  textDiv.appendChild(TextArea);

  let closeBtn = document.createElement("BUTTON");
  closeBtn.classList = "btn-close hide ";
  closeBtn.type = "button";
  closeBtn.ariaLabel = "Close";
  textDiv.appendChild(closeBtn);

  let lineP = document.createElement("P");
  lineP.classList = "lineP";
  noteDiv.appendChild(lineP);

  // הכנסת טקסט לפתק
  TextArea.innerText = mainInput;
  lineP.innerText = `${dateInput}
    ${timeInput}`;

  // כפתור מחיקה
  closeBtn.addEventListener("click", function () {
    noteDiv.remove();
    deleateNoteFromStorge(placeInArry);
  });
}

// העלאת פתקים מהסטורג'
function printStoredNotes() {
  const savedNotesArrayJson = localStorage.getItem("stored-notes");
  if (savedNotesArrayJson === null) {
    return;
  } else {
    const notesArray = JSON.parse(savedNotesArrayJson);
    // הדפסת פתקים
    for (let i = 0; i < notesArray.length; i++) {
      printNote(notesArray[i].text, notesArray[i].date, notesArray[i].time, i);
    }
  }
}

// מחיקה מהסטורג'
function deleateNoteFromStorge(placeInArry) {
  const savedNotesArrayJson = localStorage.getItem("stored-notes");
  const notesArray = JSON.parse(savedNotesArrayJson);

  notesArray.splice(placeInArry, 1);

  const notesArrayJson = JSON.stringify(notesArray);
  localStorage.setItem("stored-notes", notesArrayJson);
  location.reload();
}

// רענון לדף
function reloadTimer() {
  setTimeout(function () {
    location.reload();
  }, 2500);
}

//function formreset() {
// document.getElementById("mainForm").reset();
//}

//function clearBox() {
//  document.getElementById("formDiv").innerHTML = "";
//}

function reset() {
  let a = mainInput.value;
  a.innerText = "";

  let b = dateInput.value;
  b.innerText = "";

  let c = timeInput.value;
  c.innerText = "";
  //TextArea.innerText = mainInput;
  //lineP.innerText = `${dateInput}
  //  ${timeInput}`;
}
